import asyncio
import json
import logging
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path

import serial
import serial.tools.list_ports
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("dlum")

FRAME_COUNT_MAX = 8
SERIAL_BAUD = int(os.environ.get("DLUM_BAUD", "115200"))
SERIAL_RECONNECT_DELAY = 2.0
HEARTBEAT_INTERVAL = 2.0
SERIAL_PORT_OVERRIDE = os.environ.get("DLUM_SERIAL_PORT")
HTTP_HOST = os.environ.get("DLUM_HOST", "0.0.0.0")
HTTP_PORT = int(os.environ.get("DLUM_PORT", "8000"))

STATIC_DIR = Path(__file__).parent / "static"
MOTOR_MAP_PATH = Path(__file__).parent / "motor_map.json"
SETTINGS_PATH = Path(__file__).parent / "settings.json"
LIBRARY_DIR = Path(__file__).parent / "library"

from motor_map import MotorMap
from settings_store import SettingsStore
from library import PatternLibrary
import wifi as wifi_mod

settings = SettingsStore(SETTINGS_PATH)
motor_map = MotorMap(MOTOR_MAP_PATH, frame_count=int(settings.get("frame_count") or 4))
library = PatternLibrary(LIBRARY_DIR)


def FRAME_COUNT() -> int:
    return int(settings.get("frame_count") or 4)


def find_unoq_port() -> str | None:
    if SERIAL_PORT_OVERRIDE:
        return SERIAL_PORT_OVERRIDE
    for p in serial.tools.list_ports.comports():
        if p.vid == 0x2341 and p.pid == 0x0078:
            return p.device
    return None


class MCUBridge:
    """Owns the serial connection to the MCU. Reads JSON lines, broadcasts to clients,
    and accepts outgoing commands. Reconnects automatically when the port disappears."""

    def __init__(self, hub: "Hub"):
        self.hub = hub
        self.port: str | None = None
        self.ser: serial.Serial | None = None
        self.write_lock = asyncio.Lock()
        self.last_state = {"step": 0, "frames": [0] * FRAME_COUNT_MAX, "connected": False, "rest": False}

    async def run(self):
        loop = asyncio.get_running_loop()
        buffer = b""
        while True:
            if self.ser is None:
                self.port = find_unoq_port()
                if self.port is None:
                    await self._set_connected(False)
                    await asyncio.sleep(SERIAL_RECONNECT_DELAY)
                    continue
                try:
                    self.ser = await loop.run_in_executor(
                        None, lambda: serial.Serial(self.port, SERIAL_BAUD, timeout=0.05)
                    )
                    await self._set_connected(True)
                    log.info("Serial open on %s", self.port)
                    buffer = b""
                except (serial.SerialException, OSError) as e:
                    log.warning("Serial open failed (%s): %s", self.port, e)
                    self.ser = None
                    await asyncio.sleep(SERIAL_RECONNECT_DELAY)
                    continue
            try:
                chunk = await loop.run_in_executor(None, self.ser.read, 256)
            except (serial.SerialException, OSError) as e:
                log.warning("Serial read error: %s", e)
                await self._close()
                continue
            if not chunk:
                await asyncio.sleep(0.01)
                continue
            buffer += chunk
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line.decode("utf-8", errors="replace"))
                except json.JSONDecodeError:
                    log.debug("Non-JSON from MCU: %r", line)
                    continue
                await self._handle_mcu_event(msg)

    async def _handle_mcu_event(self, msg: dict):
        if msg.get("evt") == "state":
            frames = msg.get("frames", [0] * FRAME_COUNT())
            self.last_state["step"] = int(msg.get("step", self.last_state["step"]))
            self.last_state["frames"] = [int(x) for x in frames][:FRAME_COUNT()]
            if "rest" in msg:
                self.last_state["rest"] = bool(msg["rest"])
        elif msg.get("evt") == "button":
            # Backend-only handler. We do NOT broadcast button events to web
            # clients : an old cached JS could otherwise re-emit next_step
            # and double-advance the sequence.
            now = time.monotonic()
            last = getattr(self, "_last_button_t", 0.0)
            if now - last < 1.5:
                log.info("Button event IGNORED (backend debounce, %.0fms since last)",
                         (now - last) * 1000)
            else:
                self._last_button_t = now
                log.info("Physical button press → next_step")
                try:
                    await seq.next_step()
                except Exception as e:
                    log.warning("Button advance failed: %s", e)
            return  # <-- skip broadcast for button events
        await self.hub.broadcast({"type": "mcu_event", "data": msg})

    async def _set_connected(self, connected: bool):
        if self.last_state["connected"] != connected:
            self.last_state["connected"] = connected
            await self.hub.broadcast(
                {"type": "mcu_status", "connected": connected, "port": self.port}
            )
            if connected:
                # Push current frame count + persisted servo angles to the MCU.
                await asyncio.sleep(0.5)
                fc = FRAME_COUNT()
                await self.send({"cmd": "set_frame_count", "count": fc})
                downs = settings.get("down_angles") or [30] * FRAME_COUNT_MAX
                ups = settings.get("up_angles") or [130] * FRAME_COUNT_MAX
                for i in range(fc):
                    await self.send({"cmd": "set_angle", "motor": i, "down": int(downs[i]), "up": int(ups[i])})

    async def _close(self):
        if self.ser is not None:
            try:
                self.ser.close()
            except Exception:
                pass
        self.ser = None
        await self._set_connected(False)
        await asyncio.sleep(SERIAL_RECONNECT_DELAY)

    async def send(self, cmd: dict) -> bool:
        if self.ser is None:
            return False
        line = (json.dumps(cmd) + "\n").encode("utf-8")
        async with self.write_lock:
            try:
                await asyncio.get_running_loop().run_in_executor(
                    None, self.ser.write, line
                )
                return True
            except (serial.SerialException, OSError) as e:
                log.warning("Serial write error: %s", e)
                await self._close()
                return False


class Hub:
    """Tracks connected websocket clients and broadcasts events to them."""

    def __init__(self):
        self.clients: set[WebSocket] = set()
        self.lock = asyncio.Lock()

    async def add(self, ws: WebSocket):
        async with self.lock:
            self.clients.add(ws)

    async def remove(self, ws: WebSocket):
        async with self.lock:
            self.clients.discard(ws)

    async def broadcast(self, payload: dict):
        text = json.dumps(payload)
        async with self.lock:
            dead = []
            for ws in self.clients:
                try:
                    await ws.send_text(text)
                except Exception:
                    dead.append(ws)
            for ws in dead:
                self.clients.discard(ws)


class Sequencer:
    """Plays a pattern step-by-step, advancing on physical button presses or
    on a Linux-side 'next' command."""

    def __init__(self, mcu: MCUBridge, hub: Hub):
        self.mcu = mcu
        self.hub = hub
        self.pattern: list[list[int]] = []
        self.index = 0
        self.active = False
        # Optional rich draft data for LED preview rendering
        self.draft_threading: list[int] = []
        self.draft_logical_liftplan: list[list[int]] = []  # before mapping
        # Auto-play state
        self.auto_task: asyncio.Task | None = None
        self.auto_interval_ms: int = 5000
        self.auto_paused: bool = False
        self.next_allowed_at: float = 0.0

    def _remaining_hold_ms(self) -> int:
        return max(0, int((self.next_allowed_at - time.monotonic()) * 1000))

    async def load(self, pattern: list[list[int]], threading: list[int] | None = None,
                   logical_liftplan: list[list[int]] | None = None):
        fc = FRAME_COUNT()
        cleaned = []
        for row in pattern:
            row = [int(x) for x in row][:fc]
            row += [0] * (fc - len(row))
            raised = sum(row)
            if 1 <= raised <= (fc - 1):
                cleaned.append(row)
        self.pattern = cleaned
        self.draft_threading = list(threading or [])
        self.draft_logical_liftplan = [list(r) for r in (logical_liftplan or [])]
        self.index = 0
        self.active = bool(cleaned)
        self.next_allowed_at = 0.0
        await self.stop_auto()
        # Push initial LED preview centered on the first pick so user sees the
        # upcoming motif on the matrix immediately, even before clicking
        # "Duite suivante".
        if self.active:
            # Réveil automatique des servos : on quitte le mode repos pour
            # pouvoir actionner les cadres
            await self.mcu.send({"cmd": "set_rest", "on": False})
            # Marque de fabrique au démarrage du tissage : "5426 DLUM" scrolle
            await self.mcu.send({"cmd": "led_brand"})
            # Le scroll "5426 DLUM" prend ~5s (60ms/pixel × ~85 pixels)
            await asyncio.sleep(5.0)
            await self._push_led_drawdown(0)
        else:
            await self.mcu.send({"cmd": "led_clear"})
        await self._announce()

    async def _step_with_tassage(self, target_index: int):
        delay_ms = int(settings.get("tassage_delay_ms") or 0)
        await self.mcu.send({"cmd": "all_down"})
        await self.hub.broadcast({"type": "tassage", "phase": "down", "ms": delay_ms})
        # Pendant le tassage, la moitié haute de la LED s'éteint (tous
        # cadres bas) tandis que la moitié basse continue d'afficher la
        # dernière duite tissée — feedback visuel "tassage en cours".
        await self._push_led_drawdown_tassage(target_index)
        if delay_ms > 0:
            await asyncio.sleep(delay_ms / 1000.0)
        row = self.pattern[target_index]
        await self.mcu.send({"cmd": "lift", "step": target_index, "frames": row})
        await self.hub.broadcast({"type": "tassage", "phase": "lift"})
        hold_ms = max(0, int(settings.get("lift_hold_ms") or 0))
        self.next_allowed_at = time.monotonic() + (hold_ms / 1000.0)
        self.index = (target_index + 1) % len(self.pattern)
        await self._push_led_drawdown(target_index)
        await self._announce()

    async def _push_led_drawdown_tassage(self, upcoming_pick: int):
        """LED pendant le tassage : on affiche les 8 dernières duites
        DÉJÀ tissées (= avant la nouvelle qui arrive). Effet visuel : la
        duite courante (en bas) est figée, on attend le prochain tissage."""
        if not self.draft_threading or not self.draft_logical_liftplan:
            return
        fc = FRAME_COUNT()
        rows = [0] * 8
        for r in range(8):
            pick = (upcoming_pick - 1) - (7 - r)  # r=7 → pick déjà tissée
            if pick < 0 or pick >= len(self.draft_logical_liftplan):
                continue
            liftrow = self.draft_logical_liftplan[pick]
            bits = 0
            for c in range(12):
                if c < len(self.draft_threading):
                    shaft = self.draft_threading[c]
                    if 0 <= shaft < fc and shaft < len(liftrow) and liftrow[shaft]:
                        bits |= (1 << c)
            rows[r] = bits
        await self.mcu.send({"cmd": "led_set", "rows": rows})

    async def _push_led_drawdown(self, current_pick: int):
        """Push 8 rows of drawdown to the MCU.

        Pure drawdown view : the 8 LED rows show the 8 most recent picks of
        the cloth being woven, oldest at the top, current pick at the bottom.
        For each cell (row r, col c) : LED on if the warp end at column c
        has its shaft up at the corresponding pick (= warp shows at that point
        in the cloth).

        As the user advances, rows shift up : the bottom row is always the
        current pick, so the user sees the pattern accumulating row-by-row
        like real weaving.
        """
        if not self.draft_threading or not self.draft_logical_liftplan:
            return
        rows = [0] * 8
        fc = FRAME_COUNT()
        for r in range(8):
            pick = current_pick - (7 - r)  # r=0 → pick-7 (oldest), r=7 → current
            if pick < 0 or pick >= len(self.draft_logical_liftplan):
                continue
            liftrow = self.draft_logical_liftplan[pick]
            bits = 0
            for c in range(12):
                if c < len(self.draft_threading):
                    shaft = self.draft_threading[c]
                    if 0 <= shaft < fc and shaft < len(liftrow) and liftrow[shaft]:
                        bits |= (1 << c)
            rows[r] = bits
        log.info("LED draw pick=%d rows=[%s]", current_pick,
                 " ".join(f"{r:03X}" for r in rows))
        await self.mcu.send({"cmd": "led_set", "rows": rows})

    async def start_auto(self, interval_ms: int):
        await self.stop_auto()
        self.auto_interval_ms = max(500, int(interval_ms))
        self.auto_paused = False
        self.auto_task = asyncio.create_task(self._auto_loop())
        await self.hub.broadcast({"type": "auto_play", "active": True, "interval_ms": self.auto_interval_ms})
        await self._announce()

    async def stop_auto(self):
        if self.auto_task is not None:
            self.auto_task.cancel()
            try:
                await self.auto_task
            except (asyncio.CancelledError, Exception):
                pass
            self.auto_task = None
            self.auto_paused = False
            await self.hub.broadcast({"type": "auto_play", "active": False, "interval_ms": self.auto_interval_ms})
            await self._announce()

    async def pause_auto(self):
        if self.auto_task is None:
            return
        self.auto_paused = True
        await self.hub.broadcast({"type": "auto_play", "active": True, "paused": True, "interval_ms": self.auto_interval_ms})
        await self._announce()

    async def resume_auto(self):
        if self.auto_task is None:
            return
        self.auto_paused = False
        await self.hub.broadcast({"type": "auto_play", "active": True, "paused": False, "interval_ms": self.auto_interval_ms})
        await self._announce()

    async def _auto_loop(self):
        try:
            while self.active and self.pattern:
                if self.auto_paused:
                    await asyncio.sleep(0.1)
                    continue
                await self.next_step()
                # Keep frames up for at least lift_hold_ms, while preserving the
                # existing auto interval if it is longer.
                wait_ms = max(self.auto_interval_ms, self._remaining_hold_ms())
                await asyncio.sleep(wait_ms / 1000.0)
        except asyncio.CancelledError:
            return

    async def next_step(self):
        if not self.active or not self.pattern:
            return
        remaining_ms = self._remaining_hold_ms()
        if remaining_ms > 0 and not self.auto_paused:
            await self.hub.broadcast({"type": "hold", "remaining_ms": remaining_ms})
            return
        await self._step_with_tassage(self.index)

    async def prev_step(self):
        if not self.active or not self.pattern:
            return
        remaining_ms = self._remaining_hold_ms()
        if remaining_ms > 0 and not self.auto_paused:
            await self.hub.broadcast({"type": "hold", "remaining_ms": remaining_ms})
            return
        target = (self.index - 2) % len(self.pattern)
        await self._step_with_tassage(target)

    async def stop(self):
        await self.stop_auto()
        self.active = False
        self.next_allowed_at = 0.0
        await self.mcu.send({"cmd": "all_down"})
        await self.mcu.send({"cmd": "led_clear"})
        await self._announce()

    async def _announce(self):
        await self.hub.broadcast(
            {
                "type": "sequencer",
                "active": self.active,
                "index": self.index,
                "size": len(self.pattern),
                "preview": self.pattern[self.index] if self.active and self.pattern else None,
                "auto": self.auto_task is not None,
                "auto_paused": self.auto_paused,
                "auto_interval_ms": self.auto_interval_ms,
                "lift_hold_ms": max(0, int(settings.get("lift_hold_ms") or 0)),
                "hold_remaining_ms": self._remaining_hold_ms(),
            }
        )


hub = Hub()
mcu = MCUBridge(hub)
seq = Sequencer(mcu, hub)


async def network_status_poller():
    """Poll WiFi connection state every 30s. When in DLUM-Hotspot mode, push
    a "HOTSPOT" scrolling text to the LED matrix to remind the user that
    the carte is in fallback mode (= no known WiFi available)."""
    last_mode = None
    last_station_display = None

    def format_station_text(ssid: str, ip4: str) -> str:
        ip_only = (ip4 or "").split("/", 1)[0]
        parts = [ssid, ip_only]
        return " ".join(parts * 3)

    while True:
        try:
            await asyncio.sleep(5)
            info = await wifi_mod.status()
            mode = info.get("mode", "off")
            if mode != last_mode:
                log.info("Network mode changed: %s -> %s", last_mode, mode)
                last_mode = mode
            if mode == "hotspot":
                # Indicate hotspot mode visually on the LED matrix
                await mcu.send({"cmd": "led_text", "text": "HOTSPOT 192.168.42.1"})
                last_station_display = None
            elif mode == "station":
                ssid = info.get("active_connection") or ""
                ip4 = info.get("ip4") or ""
                if ssid and ip4:
                    station_display = (ssid, ip4)
                    if station_display != last_station_display:
                        await mcu.send({"cmd": "led_text", "text": format_station_text(ssid, ip4)})
                        last_station_display = station_display
                else:
                    last_station_display = None
        except Exception as e:
            log.warning("network_status_poller: %s", e)


@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(mcu.run())
    net_task = asyncio.create_task(network_status_poller())
    yield
    task.cancel()
    net_task.cancel()
    for t in (task, net_task):
        try:
            await t
        except asyncio.CancelledError:
            pass


app = FastAPI(lifespan=lifespan, title="DLUM Server")


@app.get("/")
async def index():
    return FileResponse(STATIC_DIR / "index.html")


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/api/state")
async def api_state():
    return {
        "mcu": mcu.last_state,
        "sequencer": {
            "active": seq.active,
            "index": seq.index,
            "size": len(seq.pattern),
        },
    }


# --- WiFi management ---


@app.get("/api/wifi/status")
async def api_wifi_status():
    return await wifi_mod.status()


@app.get("/api/wifi/scan")
async def api_wifi_scan():
    return await wifi_mod.scan()


@app.post("/api/wifi/connect")
async def api_wifi_connect(payload: dict):
    ssid = payload.get("ssid", "")
    password = payload.get("password")
    return await wifi_mod.connect(ssid, password)


@app.post("/api/wifi/forget")
async def api_wifi_forget(payload: dict):
    name = payload.get("name", "")
    return await wifi_mod.forget(name)


@app.post("/api/wifi/hotspot")
async def api_wifi_hotspot(payload: dict):
    return await wifi_mod.hotspot(bool(payload.get("on")))


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    await hub.add(ws)
    try:
        await ws.send_text(json.dumps({
            "type": "hello", "mcu": mcu.last_state,
            "mapping": motor_map.info(), "settings": settings.info(),
            "frame_count": FRAME_COUNT(), "frame_count_max": FRAME_COUNT_MAX,
        }))
        await seq._announce()
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            await dispatch(msg, ws)
    except WebSocketDisconnect:
        pass
    finally:
        await hub.remove(ws)


async def dispatch(msg: dict, ws: WebSocket):
    t = msg.get("type")
    if t == "lift":
        fc = FRAME_COUNT()
        frames = msg.get("frames", [])
        if len(frames) != fc or not (1 <= sum(int(x) for x in frames) <= (fc - 1)):
            await ws.send_text(
                json.dumps({"type": "error", "code": "invalid_frames"})
            )
            return
        phys = motor_map.to_physical_frames([int(x) for x in frames])
        await mcu.send({"cmd": "lift", "step": int(msg.get("step", 0)), "frames": phys})
    elif t == "manual":
        # Logical cadre index from UI -> map to physical position
        logical_idx = int(msg["frame"])
        if not (0 <= logical_idx < FRAME_COUNT()):
            return
        phys_idx = motor_map.logical_to_physical[logical_idx]
        await mcu.send({"cmd": "manual", "frame": phys_idx, "state": int(msg["state"])})
    elif t == "all_down":
        await mcu.send({"cmd": "all_down"})
    elif t == "all_up":
        await mcu.send({"cmd": "all_up"})
    elif t == "pin_test":
        # Direct physical pin test, no mapping translation
        await mcu.send({"cmd": "pin_test", "pin": int(msg["pin"])})
    elif t == "get_mapping":
        await ws.send_text(json.dumps({"type": "mapping", "data": motor_map.info()}))
    elif t == "set_mapping":
        ok = motor_map.set(msg.get("logical_to_physical", []))
        await ws.send_text(json.dumps({"type": "mapping", "ok": ok, "data": motor_map.info()}))
    elif t == "reset_mapping":
        motor_map.reset()
        await ws.send_text(json.dumps({"type": "mapping", "ok": True, "data": motor_map.info()}))
    elif t == "get_settings":
        await ws.send_text(json.dumps({"type": "settings", "data": settings.info()}))
    elif t == "set_setting":
        key = msg.get("key")
        value = msg.get("value")
        if key in ("tassage_delay_ms", "lift_hold_ms"):
            value = max(0, int(value or 0))
        elif key == "frame_count":
            value = max(2, min(FRAME_COUNT_MAX, int(value)))
        ok = settings.set(key, value)
        # Special handling : if frame_count changed, propagate to motor_map and MCU.
        if ok and key == "frame_count":
            new_fc = max(2, min(FRAME_COUNT_MAX, int(value)))
            motor_map.set_frame_count(new_fc)
            await mcu.send({"cmd": "set_frame_count", "count": new_fc})
            await ws.send_text(json.dumps({"type": "mapping", "ok": True, "data": motor_map.info()}))
        await ws.send_text(json.dumps({"type": "settings", "ok": ok, "data": settings.info()}))
    elif t == "set_motor_angle":
        # Update one motor's down or up angle. Persists locally + pushes to MCU.
        # Logical motor index is translated through the mapping.
        motor_logical = int(msg["motor"])
        if not (0 <= motor_logical < FRAME_COUNT()):
            return
        motor_phys = motor_map.logical_to_physical[motor_logical]
        kind = msg.get("kind", "")
        value = int(msg["value"])
        if kind not in ("down", "up"):
            return
        key = f"{kind}_angles"
        arr = list(settings.get(key))
        # Stored arrays are indexed by PHYSICAL pin (matches firmware).
        arr[motor_phys] = value
        settings.set(key, arr)
        await mcu.send({"cmd": "set_angle", "motor": motor_phys, kind: value})
        await ws.send_text(json.dumps({"type": "settings", "ok": True, "data": settings.info()}))
    elif t == "live_servo":
        # Direct test position. Physical motor index used as-is (this is for calibration).
        await mcu.send({"cmd": "live_servo", "motor": int(msg["motor"]), "angle": int(msg["angle"])})
    elif t == "led_test":
        await mcu.send({"cmd": "led_test"})
    elif t == "led_debug":
        await mcu.send({"cmd": "led_debug"})
    elif t == "led_brand":
        await mcu.send({"cmd": "led_brand"})
    elif t == "set_rest":
        await mcu.send({"cmd": "set_rest", "on": bool(msg.get("on"))})
    elif t == "library_list":
        await ws.send_text(json.dumps({"type": "library_list", "data": library.list()}))
    elif t == "library_get":
        d = library.get(msg.get("id", ""))
        await ws.send_text(json.dumps({"type": "library_entry", "data": d}))
    elif t == "library_save":
        rec = library.save(msg.get("payload", {}))
        await ws.send_text(json.dumps({"type": "library_saved", "data": rec}))
    elif t == "library_delete":
        ok = library.delete(msg.get("id", ""))
        await ws.send_text(json.dumps({"type": "library_deleted", "ok": ok, "id": msg.get("id")}))
    elif t == "ping_mcu":
        await mcu.send({"cmd": "ping"})
    elif t == "load_pattern":
        # Translate each row to physical order before storing in sequencer
        raw_pattern = msg.get("pattern", [])
        threading = msg.get("threading") or []
        phys_pattern = [motor_map.to_physical_frames([int(x) for x in row]) for row in raw_pattern]
        # Store the LOGICAL liftplan as well so the LED drawdown rendering
        # uses the user-visible cadre numbering (1-4) which matches the threading.
        await seq.load(
            phys_pattern,
            threading=[int(x) for x in threading],
            logical_liftplan=[[int(x) for x in row] for row in raw_pattern],
        )
    elif t == "next_step":
        await seq.next_step()
    elif t == "prev_step":
        await seq.prev_step()
    elif t == "stop_sequence":
        await seq.stop()
    elif t == "auto_play_start":
        await seq.start_auto(int(msg.get("interval_ms", 5000)))
    elif t == "auto_play_pause":
        await seq.pause_auto()
    elif t == "auto_play_resume":
        await seq.resume_auto()
    elif t == "auto_play_stop":
        await seq.stop_auto()
    else:
        await ws.send_text(json.dumps({"type": "error", "code": "unknown_type", "t": t}))


if __name__ == "__main__":
    import uvicorn

    log.info("Starting on %s:%d (serial=%s)", HTTP_HOST, HTTP_PORT, SERIAL_PORT_OVERRIDE or "auto-detect")
    uvicorn.run(app, host=HTTP_HOST, port=HTTP_PORT, log_level="info")
